-- Migrations for Hamburgueria Miraculos App

-- Drop existing tables if they exist (for development reset)
DROP TABLE IF EXISTS order_item_customizations;
DROP TABLE IF EXISTS order_items;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS product_ingredients;
DROP TABLE IF EXISTS ingredients;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS categories;
DROP TABLE IF EXISTS tables;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS settings;
DROP TABLE IF EXISTS waiter_calls;

-- Create categories table
CREATE TABLE categories (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    description TEXT,
    image_url TEXT,
    display_order INTEGER DEFAULT 0,
    active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create products table
CREATE TABLE products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    category_id INTEGER NOT NULL,
    name TEXT NOT NULL,
    description TEXT,
    price REAL NOT NULL, -- Use REAL for decimal numbers in SQLite
    image_url TEXT,
    preparation_time INTEGER, -- tempo estimado em minutos
    highlight BOOLEAN DEFAULT FALSE,
    active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id)
);

-- Create ingredients table
CREATE TABLE ingredients (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    description TEXT,
    additional_price REAL DEFAULT 0.00,
    active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create product_ingredients table
CREATE TABLE product_ingredients (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    product_id INTEGER NOT NULL,
    ingredient_id INTEGER NOT NULL,
    is_default BOOLEAN DEFAULT TRUE,
    can_remove BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES products(id),
    FOREIGN KEY (ingredient_id) REFERENCES ingredients(id)
);

-- Create tables table
CREATE TABLE tables (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    number INTEGER NOT NULL UNIQUE,
    description TEXT,
    qr_code TEXT,
    status TEXT DEFAULT 'available', -- available, occupied, reserved, maintenance
    active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create orders table
CREATE TABLE orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    table_id INTEGER NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending', -- pending, preparing, ready, delivered, cancelled
    total_amount REAL NOT NULL,
    service_fee REAL DEFAULT 0.00,
    payment_method TEXT,
    payment_status TEXT DEFAULT 'pending', -- pending, paid, cancelled
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (table_id) REFERENCES tables(id)
);

-- Create order_items table
CREATE TABLE order_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id INTEGER NOT NULL,
    product_id INTEGER NOT NULL,
    quantity INTEGER NOT NULL DEFAULT 1,
    unit_price REAL NOT NULL,
    subtotal REAL NOT NULL,
    notes TEXT,
    status TEXT DEFAULT 'pending', -- pending, preparing, ready, delivered, cancelled
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(id),
    FOREIGN KEY (product_id) REFERENCES products(id)
);

-- Create order_item_customizations table
CREATE TABLE order_item_customizations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_item_id INTEGER NOT NULL,
    ingredient_id INTEGER NOT NULL,
    action TEXT NOT NULL, -- add, remove
    additional_price REAL DEFAULT 0.00,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_item_id) REFERENCES order_items(id),
    FOREIGN KEY (ingredient_id) REFERENCES ingredients(id)
);

-- Create waiter_calls table
CREATE TABLE waiter_calls (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    table_id INTEGER NOT NULL,
    reason TEXT NOT NULL, -- help, payment, question, other
    description TEXT,
    status TEXT DEFAULT 'pending', -- pending, attending, resolved
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (table_id) REFERENCES tables(id)
);

-- Create users table
CREATE TABLE users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    username TEXT NOT NULL UNIQUE,
    password TEXT NOT NULL, -- Store hashed passwords
    role TEXT NOT NULL, -- admin, manager, kitchen, waiter
    active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create settings table
CREATE TABLE settings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    key TEXT NOT NULL UNIQUE,
    value TEXT NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create Indexes
CREATE INDEX idx_products_category ON products(category_id);
CREATE INDEX idx_product_ingredients_product ON product_ingredients(product_id);
CREATE INDEX idx_orders_table ON orders(table_id);
CREATE INDEX idx_orders_status ON orders(status);
CREATE INDEX idx_order_items_order ON order_items(order_id);
CREATE INDEX idx_order_items_product ON order_items(product_id);
CREATE INDEX idx_order_item_customizations_item ON order_item_customizations(order_item_id);
CREATE INDEX idx_waiter_calls_table ON waiter_calls(table_id);
CREATE INDEX idx_waiter_calls_status ON waiter_calls(status);

-- Insert initial data
INSERT INTO categories (name, description, display_order) VALUES
('Lanches de Frango', 'Nossos deliciosos lanches de frango', 1),
('Petiscos', 'Porções para compartilhar', 2),
('Batatas', 'Batatas fritas crocantes', 3),
('Bebidas', 'Refrigerantes, sucos e água', 4);

INSERT INTO ingredients (name, additional_price) VALUES
('Pão Brioche', 0.00),
('Peito de Frango Grelhado', 0.00),
('Peito de Frango Empanado', 0.00),
('Alface Americana', 0.00),
('Tomate', 0.00),
('Cebola Roxa', 0.00),
('Queijo Cheddar', 2.00),
('Queijo Mussarela', 1.50),
('Bacon Crocante', 3.00),
('Molho Barbecue', 1.00),
('Maionese da Casa', 1.00),
('Batata Palha', 1.00);

INSERT INTO products (category_id, name, description, price, image_url, preparation_time) VALUES
(1, 'Frango Clássico', 'Pão brioche, peito de frango grelhado, alface, tomate e maionese da casa.', 19.90, '/images/products/frango_classico.jpg', 15),
(1, 'Frango Crispy', 'Pão brioche, peito de frango empanado, alface, tomate e maionese da casa.', 21.90, '/images/products/frango_crispy.jpg', 18),
(1, 'Frango BBQ Bacon', 'Pão brioche, peito de frango grelhado, queijo cheddar, bacon crocante, cebola roxa e molho barbecue.', 25.90, '/images/products/frango_bbq_bacon.jpg', 20),
(2, 'Coxinha de Frango (6 un)', 'Porção com 6 coxinhas de frango cremosas.', 18.00, '/images/products/coxinha.jpg', 12),
(2, 'Frango a Passarinho', 'Pedaços de frango fritos com alho e salsinha.', 28.00, '/images/products/frango_passarinho.jpg', 20),
(3, 'Batata Frita Simples', 'Porção de batata frita sequinha.', 15.00, '/images/products/batata_simples.jpg', 10),
(3, 'Batata Frita com Cheddar e Bacon', 'Porção de batata frita coberta com queijo cheddar cremoso e bacon crocante.', 22.00, '/images/products/batata_cheddar_bacon.jpg', 15),
(4, 'Coca-Cola Lata', 'Refrigerante Coca-Cola 350ml.', 6.00, '/images/products/coca_lata.jpg', 1),
(4, 'Guaraná Antarctica Lata', 'Refrigerante Guaraná Antarctica 350ml.', 6.00, '/images/products/guarana_lata.jpg', 1),
(4, 'Água Mineral sem Gás', 'Água mineral 500ml.', 4.00, '/images/products/agua_sem_gas.jpg', 1);

-- Default ingredients for products (example for Frango Clássico)
INSERT INTO product_ingredients (product_id, ingredient_id, is_default, can_remove) VALUES
(1, 1, TRUE, FALSE), -- Pão Brioche
(1, 2, TRUE, FALSE), -- Peito de Frango Grelhado
(1, 4, TRUE, TRUE),  -- Alface Americana
(1, 5, TRUE, TRUE),  -- Tomate
(1, 11, TRUE, TRUE); -- Maionese da Casa

-- Insert initial tables (1 to 15)
INSERT INTO tables (number, description) VALUES
(1, 'Mesa perto da janela'),
(2, 'Mesa central'),
(3, 'Mesa canto esquerdo'),
(4, 'Mesa canto direito'),
(5, 'Mesa 5'),
(6, 'Mesa 6'),
(7, 'Mesa 7'),
(8, 'Mesa 8'),
(9, 'Mesa 9'),
(10, 'Mesa 10'),
(11, 'Mesa 11'),
(12, 'Mesa 12'),
(13, 'Mesa 13'),
(14, 'Mesa 14'),
(15, 'Mesa 15');

-- Insert initial admin user (password: admin123 - MUST BE HASHED in real implementation)
-- Note: Hashing needs to be done in the application code before inserting
INSERT INTO users (name, username, password, role) VALUES
('Admin Miraculos', 'admin', '$2b$10$placeholderhash', 'admin'); -- Replace placeholderhash with a real bcrypt hash

-- Insert initial settings
INSERT INTO settings (key, value, description) VALUES
('restaurant_name', 'Hamburgueria Miraculos', 'Nome do restaurante exibido no aplicativo'),
('service_fee_percentage', '10', 'Percentual da taxa de serviço (0 a 100)'),
('currency_symbol', 'R$', 'Símbolo da moeda');


