"use client";

import React, { createContext, useState, useContext, ReactNode, useEffect } from 'react';

// Define the structure for a customization
interface Customization {
  ingredient_id: number;
  ingredient_name: string; // Added for display purposes
  action: 'add' | 'remove';
  additional_price: number;
}

// Define the structure for an item in the cart
export interface CartItem {
  id: string; // Unique ID for the cart item instance (e.g., product.id + timestamp or hash of customizations)
  product_id: number;
  name: string;
  quantity: number;
  unit_price: number; // Base price of the product
  customizations: Customization[];
  notes: string;
  image_url?: string | null; // Optional image URL
}

// Define the structure for the cart context
interface CartContextType {
  items: CartItem[];
  addItem: (item: Omit<CartItem, 'id'>) => void;
  removeItem: (itemId: string) => void;
  updateQuantity: (itemId: string, quantity: number) => void;
  clearCart: () => void;
  totalItems: number;
  totalPrice: number;
}

// Create the context with a default value
const CartContext = createContext<CartContextType | undefined>(undefined);

// Create a provider component
export const CartProvider = ({ children }: { children: ReactNode }) => {
  const [items, setItems] = useState<CartItem[]>(() => {
    // Load cart from localStorage on initial render
    if (typeof window !== 'undefined') {
      const savedCart = localStorage.getItem('shoppingCart');
      return savedCart ? JSON.parse(savedCart) : [];
    }
    return [];
  });

  // Save cart to localStorage whenever items change
  useEffect(() => {
    if (typeof window !== 'undefined') {
      localStorage.setItem('shoppingCart', JSON.stringify(items));
    }
  }, [items]);

  const addItem = (itemToAdd: Omit<CartItem, 'id'>) => {
    setItems(prevItems => {
      // Simple approach: always add as a new item with a unique ID
      // More complex: check if an identical item (same product + same customizations) exists and update quantity
      const newItemId = `${itemToAdd.product_id}-${Date.now()}-${Math.random()}`;
      const newItem: CartItem = { ...itemToAdd, id: newItemId };
      return [...prevItems, newItem];
    });
  };

  const removeItem = (itemId: string) => {
    setItems(prevItems => prevItems.filter(item => item.id !== itemId));
  };

  const updateQuantity = (itemId: string, quantity: number) => {
    setItems(prevItems =>
      prevItems.map(item =>
        item.id === itemId ? { ...item, quantity: Math.max(0, quantity) } : item
      ).filter(item => item.quantity > 0) // Remove item if quantity is 0
    );
  };

  const clearCart = () => {
    setItems([]);
  };

  const totalItems = items.reduce((sum, item) => sum + item.quantity, 0);

  const totalPrice = items.reduce((sum, item) => {
    const itemBasePrice = item.unit_price;
    const customizationPrice = item.customizations.reduce((custSum, cust) => {
        // Only add price for 'add' actions
        return cust.action === 'add' ? custSum + cust.additional_price : custSum;
    }, 0);
    return sum + (itemBasePrice + customizationPrice) * item.quantity;
  }, 0);

  return (
    <CartContext.Provider value={{ items, addItem, removeItem, updateQuantity, clearCart, totalItems, totalPrice }}>
      {children}
    </CartContext.Provider>
  );
};

// Create a custom hook to use the cart context
export const useCart = () => {
  const context = useContext(CartContext);
  if (context === undefined) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
};

