"use client";

import { useCart } from '@/context/CartContext';
import Link from 'next/link';

export default function CartPage() {
  const { items, removeItem, updateQuantity, totalItems, totalPrice } = useCart();

  if (items.length === 0) {
    return (
      <div className="container mx-auto p-4 md:p-8">
        <h1 className="text-2xl font-bold mb-6">Seu Carrinho</h1>
        <div className="bg-white rounded-lg shadow-md p-6 text-center">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 mx-auto text-gray-400 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" />
          </svg>
          <h2 className="text-xl font-semibold mb-2">Seu carrinho está vazio</h2>
          <p className="text-gray-600 mb-6">Adicione alguns itens deliciosos para começar seu pedido!</p>
          <Link href="/" className="bg-red-600 text-white font-semibold py-2 px-4 rounded-md hover:bg-red-700 transition-colors duration-200">
            Ver Cardápio
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-4 md:p-8">
      <h1 className="text-2xl font-bold mb-6">Seu Carrinho</h1>
      
      <div className="bg-white rounded-lg shadow-md overflow-hidden mb-6">
        <div className="p-4 border-b border-gray-200">
          <h2 className="text-lg font-semibold">Itens do Pedido ({totalItems})</h2>
        </div>
        
        <ul className="divide-y divide-gray-200">
          {items.map((item) => (
            <li key={item.id} className="p-4 hover:bg-gray-50">
              <div className="flex flex-col md:flex-row md:items-center">
                <div className="flex-shrink-0 mr-4">
                  {item.image_url ? (
                    <img src={item.image_url} alt={item.name} className="w-16 h-16 object-cover rounded" />
                  ) : (
                    <div className="w-16 h-16 bg-gray-200 rounded flex items-center justify-center">
                      <span className="text-gray-500 text-xs">Sem imagem</span>
                    </div>
                  )}
                </div>
                
                <div className="flex-grow">
                  <h3 className="text-lg font-medium">{item.name}</h3>
                  
                  {item.customizations.length > 0 && (
                    <div className="mt-1 text-sm text-gray-600">
                      <p className="font-medium">Personalizações:</p>
                      <ul className="ml-2">
                        {item.customizations.map((cust, idx) => (
                          <li key={idx} className="flex items-center">
                            <span className={cust.action === 'add' ? 'text-green-600' : 'text-red-600'}>
                              {cust.action === 'add' ? '+' : '-'} {cust.ingredient_name}
                              {cust.action === 'add' && cust.additional_price > 0 && 
                                ` (+R$ ${cust.additional_price.toFixed(2)})`}
                            </span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                  
                  {item.notes && (
                    <div className="mt-1 text-sm text-gray-600">
                      <p className="font-medium">Observações:</p>
                      <p className="ml-2 italic">{item.notes}</p>
                    </div>
                  )}
                </div>
                
                <div className="flex items-center mt-4 md:mt-0">
                  <div className="flex items-center mr-4">
                    <button
                      onClick={() => updateQuantity(item.id, item.quantity - 1)}
                      className="w-8 h-8 rounded-l bg-gray-200 flex items-center justify-center hover:bg-gray-300"
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                        <path fillRule="evenodd" d="M3 10a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z" clipRule="evenodd" />
                      </svg>
                    </button>
                    <div className="w-10 h-8 border-t border-b border-gray-300 flex items-center justify-center text-sm">
                      {item.quantity}
                    </div>
                    <button
                      onClick={() => updateQuantity(item.id, item.quantity + 1)}
                      className="w-8 h-8 rounded-r bg-gray-200 flex items-center justify-center hover:bg-gray-300"
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                        <path fillRule="evenodd" d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z" clipRule="evenodd" />
                      </svg>
                    </button>
                  </div>
                  
                  <div className="text-right">
                    <div className="text-lg font-semibold">
                      R$ {((item.unit_price + 
                        item.customizations.reduce((sum, cust) => 
                          cust.action === 'add' ? sum + cust.additional_price : sum, 0)
                        ) * item.quantity).toFixed(2)}
                    </div>
                    <button
                      onClick={() => removeItem(item.id)}
                      className="text-red-600 text-sm hover:text-red-800"
                    >
                      Remover
                    </button>
                  </div>
                </div>
              </div>
            </li>
          ))}
        </ul>
      </div>
      
      <div className="bg-white rounded-lg shadow-md overflow-hidden mb-6">
        <div className="p-4 border-b border-gray-200">
          <h2 className="text-lg font-semibold">Resumo do Pedido</h2>
        </div>
        
        <div className="p-4">
          <div className="flex justify-between mb-2">
            <span>Subtotal</span>
            <span>R$ {totalPrice.toFixed(2)}</span>
          </div>
          <div className="flex justify-between mb-2">
            <span>Taxa de serviço (10%)</span>
            <span>R$ {(totalPrice * 0.1).toFixed(2)}</span>
          </div>
          <div className="border-t border-gray-200 my-2 pt-2 flex justify-between font-bold">
            <span>Total</span>
            <span>R$ {(totalPrice * 1.1).toFixed(2)}</span>
          </div>
        </div>
      </div>
      
      <div className="flex flex-col md:flex-row md:justify-between gap-4">
        <Link href="/" className="bg-gray-200 text-gray-800 font-semibold py-3 px-6 rounded-md hover:bg-gray-300 transition-colors duration-200 text-center">
          Continuar Comprando
        </Link>
        <Link href="/finalizar" className="bg-red-600 text-white font-semibold py-3 px-6 rounded-md hover:bg-red-700 transition-colors duration-200 text-center">
          Finalizar Pedido
        </Link>
      </div>
    </div>
  );
}
