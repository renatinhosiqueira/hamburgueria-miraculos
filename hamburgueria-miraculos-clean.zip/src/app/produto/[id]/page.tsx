"use client";

import { useState } from 'react';
import Link from 'next/link';
import { useCart } from '@/context/CartContext';

interface ProductDetailProps {
  params: {
    id: string;
  };
}

interface Ingredient {
  id: number;
  name: string;
  is_default: boolean;
  can_remove: boolean;
  additional_price: number;
}

interface ProductDetail {
  id: number;
  name: string;
  description: string | null;
  price: number;
  image_url: string | null;
  preparation_time: number | null;
  category: {
    id: number;
    name: string;
  };
  ingredients: Ingredient[];
}

export default function ProductDetailPage({ params }: ProductDetailProps) {
  const { addItem } = useCart(); // Get addItem function from context
  const [product, setProduct] = useState<ProductDetail | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [quantity, setQuantity] = useState(1);
  const [selectedCustomizations, setSelectedCustomizations] = useState<{[key: number]: 'add' | 'remove' | null}>({});
  const [notes, setNotes] = useState('');

  // Fetch product details on component mount
  useState(() => {
    async function fetchProductDetails() {
      setIsLoading(true);
      setError(null);
      try {
        const response = await fetch(`/api/v1/products/${params.id}`);
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        setProduct(data.data || null);
      } catch (e) {
        console.error("Failed to fetch product details:", e);
        setError("Falha ao carregar detalhes do produto.");
      } finally {
        setIsLoading(false);
      }
    }
    fetchProductDetails();
  });

  const handleIngredientToggle = (ingredientId: number, action: 'add' | 'remove') => {
    setSelectedCustomizations(prev => {
      const current = prev[ingredientId];
      // If current action is the same as new action, toggle it off
      if (current === action) {
        const newCustomizations = {...prev};
        delete newCustomizations[ingredientId];
        return newCustomizations;
      }
      // Otherwise set the new action
      return {
        ...prev,
        [ingredientId]: action
      };
    });
  };

  const calculateTotalPrice = () => {
    if (!product) return 0;
    
    let basePrice = product.price;
    let additionalPrice = 0;
    
    // Calculate additional price from customizations
    Object.entries(selectedCustomizations).forEach(([ingredientId, action]) => {
      if (action === 'add') {
        const ingredient = product.ingredients.find(i => i.id === parseInt(ingredientId));
        if (ingredient) {
          additionalPrice += ingredient.additional_price;
        }
      }
    });
    
    return (basePrice + additionalPrice) * quantity;
  };

  if (isLoading) {
    return (
      <div className="container mx-auto p-4 flex justify-center items-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-red-500 mx-auto"></div>
          <p className="mt-4 text-gray-600">Carregando detalhes do produto...</p>
        </div>
      </div>
    );
  }

  if (error || !product) {
    return (
      <div className="container mx-auto p-4">
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">
          <strong className="font-bold">Erro!</strong>
          <span className="block sm:inline"> {error || "Produto não encontrado."}</span>
        </div>
        <div className="mt-4">
          <Link href="/" className="text-blue-500 hover:underline">
            ← Voltar para o cardápio
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-4 md:p-8">
      <div className="mb-4">
        <Link href="/" className="text-blue-500 hover:underline flex items-center">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M9.707 16.707a1 1 0 01-1.414 0l-6-6a1 1 0 010-1.414l6-6a1 1 0 011.414 1.414L5.414 9H17a1 1 0 110 2H5.414l4.293 4.293a1 1 0 010 1.414z" clipRule="evenodd" />
          </svg>
          Voltar para o cardápio
        </Link>
      </div>

      <div className="bg-white rounded-lg shadow-lg overflow-hidden">
        <div className="md:flex">
          <div className="md:w-1/2">
            <div className="h-64 md:h-full bg-gray-200 flex items-center justify-center">
              {product.image_url ? (
                <img src={product.image_url} alt={product.name} className="h-full w-full object-cover" />
              ) : (
                <div className="text-gray-500 text-center p-4">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 mx-auto text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                  </svg>
                  <p>Imagem não disponível</p>
                </div>
              )}
            </div>
          </div>
          
          <div className="md:w-1/2 p-6">
            <div className="mb-2">
              <span className="inline-block bg-red-100 text-red-600 text-xs px-2 py-1 rounded-full uppercase tracking-wide">
                {product.category.name}
              </span>
            </div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">{product.name}</h1>
            {product.description && (
              <p className="text-gray-600 mb-4">{product.description}</p>
            )}
            <div className="mb-4">
              <span className="text-2xl font-bold text-red-600">R$ {product.price.toFixed(2)}</span>
            </div>
            {product.preparation_time && (
              <div className="mb-4 flex items-center text-gray-600">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z" clipRule="evenodd" />
                </svg>
                <span>Tempo de preparo: {product.preparation_time} minutos</span>
              </div>
            )}
          </div>
        </div>

        <div className="p-6 border-t border-gray-200">
          <h2 className="text-xl font-semibold mb-4">Personalize seu pedido</h2>
          
          {/* Ingredients Section */}
          <div className="mb-6">
            <h3 className="text-lg font-medium mb-2">Ingredientes</h3>
            <div className="space-y-2">
              {product.ingredients.filter(i => i.is_default).map(ingredient => (
                <div key={ingredient.id} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                  <span>{ingredient.name}</span>
                  {ingredient.can_remove && (
                    <button
                      onClick={() => handleIngredientToggle(ingredient.id, 'remove')}
                      className={`px-3 py-1 rounded text-sm font-medium ${
                        selectedCustomizations[ingredient.id] === 'remove'
                          ? 'bg-red-500 text-white'
                          : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                      }`}
                    >
                      Remover
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>
          
          {/* Additional Ingredients Section */}
          <div className="mb-6">
            <h3 className="text-lg font-medium mb-2">Ingredientes Adicionais</h3>
            <div className="space-y-2">
              {product.ingredients.filter(i => !i.is_default && i.additional_price > 0).map(ingredient => (
                <div key={ingredient.id} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                  <span>{ingredient.name} (+R$ {ingredient.additional_price.toFixed(2)})</span>
                  <button
                    onClick={() => handleIngredientToggle(ingredient.id, 'add')}
                    className={`px-3 py-1 rounded text-sm font-medium ${
                      selectedCustomizations[ingredient.id] === 'add'
                        ? 'bg-green-500 text-white'
                        : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                    }`}
                  >
                    Adicionar
                  </button>
                </div>
              ))}
            </div>
          </div>
          
          {/* Notes Section */}
          <div className="mb-6">
            <h3 className="text-lg font-medium mb-2">Observações</h3>
            <textarea
              className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-transparent"
              rows={3}
              placeholder="Ex: Sem cebola, bem passado..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
            ></textarea>
          </div>
          
          {/* Quantity Section */}
          <div className="mb-6">
            <h3 className="text-lg font-medium mb-2">Quantidade</h3>
            <div className="flex items-center">
              <button
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
                className="w-10 h-10 rounded-l bg-gray-200 flex items-center justify-center hover:bg-gray-300"
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M3 10a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z" clipRule="evenodd" />
                </svg>
              </button>
              <div className="w-12 h-10 border-t border-b border-gray-300 flex items-center justify-center text-lg">
                {quantity}
              </div>
              <button
                onClick={() => setQuantity(quantity + 1)}
                className="w-10 h-10 rounded-r bg-gray-200 flex items-center justify-center hover:bg-gray-300"
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z" clipRule="evenodd" />
                </svg>
              </button>
            </div>
          </div>
          
          {/* Total and Add to Cart */}
          <div className="flex flex-col md:flex-row md:items-center md:justify-between">
            <div className="mb-4 md:mb-0">
              <span className="text-lg text-gray-700">Total:</span>
              <span className="text-2xl font-bold text-red-600 ml-2">R$ {calculateTotalPrice().toFixed(2)}</span>
            </div>
            <button 
              onClick={handleAddToCart} // Call handleAddToCart on click
              className="bg-yellow-400 text-gray-900 font-bold py-3 px-6 rounded-lg hover:bg-yellow-500 transition-colors duration-200 flex items-center justify-center">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
                <path d="M3 1a1 1 0 000 2h1.22l.305 1.222a.997.997 0 00.01.042l1.358 5.43-.893.892C3.74 11.846 4.632 14 6.414 14H15a1 1 0 000-2H6.414l1-1H14a1 1 0 00.894-.553l3-6A1 1 0 0017 3H6.28l-.31-1.243A1 1 0 005 1H3zM16 16.5a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zM6.5 18a1.5 1.5 0 100-3 1.5 1.5 0 000 3z" />
              </svg>
              Adicionar ao Carrinho
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

  const handleAddToCart = () => {
    if (!product) return;

    // Prepare customizations array
    const customizations: Customization[] = Object.entries(selectedCustomizations)
      .map(([ingredientIdStr, action]) => {
        if (!action) return null; // Skip if action is null
        const ingredientId = parseInt(ingredientIdStr);
        const ingredient = product.ingredients.find(i => i.id === ingredientId);
        if (!ingredient) return null;
        return {
          ingredient_id: ingredient.id,
          ingredient_name: ingredient.name,
          action: action,
          additional_price: action === 'add' ? ingredient.additional_price : 0
        };
      })
      .filter((cust): cust is Customization => cust !== null); // Type guard to filter out nulls

    const itemToAdd: Omit<CartItem, 'id'> = {
      product_id: product.id,
      name: product.name,
      quantity: quantity,
      unit_price: product.price,
      customizations: customizations,
      notes: notes,
      image_url: product.image_url
    };

    addItem(itemToAdd);

    // Optional: Add feedback (e.g., show a notification, redirect)
    alert(`${quantity}x ${product.name} adicionado ao carrinho!`);
    // Consider redirecting or showing a more subtle notification
    // router.push('/carrinho'); // Example using Next.js router if needed
  };

