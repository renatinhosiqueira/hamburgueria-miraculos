import { getRequestContext } from "@cloudflare/next-on-pages";
import { NextResponse } from "next/server";

// Define the expected structure for a Product with details
interface ProductDetail {
  id: number;
  category_id: number;
  name: string;
  description: string | null;
  price: number;
  image_url: string | null;
  preparation_time: number | null;
  highlight: boolean;
  active: boolean;
}

// Define the structure for an ingredient
interface Ingredient {
  id: number;
  name: string;
  is_default: boolean;
  can_remove: boolean;
  additional_price: number;
}

export const runtime = "edge"; // Specify edge runtime

/**
 * @swagger
 * /api/v1/products/{id}:
 *   get:
 *     summary: Get product details by ID
 *     description: Retrieves detailed information about a specific product, including its ingredients.
 *     tags:
 *       - Products
 *     parameters:
 *       - in: path
 *         name: id
 *         schema:
 *           type: integer
 *         required: true
 *         description: The ID of the product to retrieve.
 *     responses:
 *       200:
 *         description: Detailed product information.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 data:
 *                   type: object
 *                   properties:
 *                     id: { type: integer }
 *                     category_id: { type: integer }
 *                     name: { type: string }
 *                     description: { type: string, nullable: true }
 *                     price: { type: number }
 *                     image_url: { type: string, nullable: true }
 *                     preparation_time: { type: integer, nullable: true }
 *                     highlight: { type: boolean }
 *                     active: { type: boolean }
 *                     category:
 *                       type: object
 *                       properties:
 *                         id: { type: integer }
 *                         name: { type: string }
 *                     ingredients:
 *                       type: array
 *                       items:
 *                         type: object
 *                         properties:
 *                           id: { type: integer }
 *                           name: { type: string }
 *                           is_default: { type: boolean }
 *                           can_remove: { type: boolean }
 *                           additional_price: { type: number }
 *       400:
 *         description: Invalid product ID parameter.
 *       404:
 *         description: Product not found.
 *       500:
 *         description: Internal server error or database error.
 */
export async function GET(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    // Get D1 database binding
    const { env } = getRequestContext();
    const db = env.DB;

    // Parse and validate the product ID
    const productId = parseInt(params.id, 10);
    if (isNaN(productId)) {
      return NextResponse.json(
        { error: "Invalid product ID. Must be an integer." },
        { status: 400 }
      );
    }

    // Fetch the product details
    const productStmt = db.prepare(`
      SELECT p.id, p.category_id, p.name, p.description, p.price, 
             p.image_url, p.preparation_time, p.highlight, p.active,
             c.id as category_id, c.name as category_name
      FROM products p
      JOIN categories c ON p.category_id = c.id
      WHERE p.id = ? AND p.active = TRUE
    `).bind(productId);
    
    const product = await productStmt.first<ProductDetail & { category_name: string }>();

    if (!product) {
      return NextResponse.json(
        { error: "Product not found or inactive" },
        { status: 404 }
      );
    }

    // Fetch the product ingredients
    const ingredientsStmt = db.prepare(`
      SELECT i.id, i.name, i.additional_price, pi.is_default, pi.can_remove
      FROM ingredients i
      JOIN product_ingredients pi ON i.id = pi.ingredient_id
      WHERE pi.product_id = ? AND i.active = TRUE
      ORDER BY pi.is_default DESC, i.name ASC
    `).bind(productId);
    
    const { results: ingredients } = await ingredientsStmt.all<Ingredient>();

    // Construct the response
    const response = {
      data: {
        ...product,
        category: {
          id: product.category_id,
          name: product.category_name
        },
        ingredients
      }
    };

    // Remove the redundant category_name field
    delete response.data.category_name;

    return NextResponse.json(response);
  } catch (error) {
    console.error("Error fetching product details:", error);
    const errorMessage = error instanceof Error ? error.message : "An unexpected error occurred";
    return NextResponse.json(
      { error: "Failed to fetch product details", details: errorMessage },
      { status: 500 }
    );
  }
}
