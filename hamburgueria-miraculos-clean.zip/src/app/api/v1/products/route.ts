import { getRequestContext } from "@cloudflare/next-on-pages";
import { NextResponse } from "next/server";

// Define the expected structure for a Product
interface Product {
  id: number;
  category_id: number;
  name: string;
  description: string | null;
  price: number;
  image_url: string | null;
  preparation_time: number | null;
  highlight: boolean;
  active: boolean;
  created_at: string;
  updated_at: string;
}

export const runtime = "edge"; // Specify edge runtime

/**
 * @swagger
 * /api/v1/products:
 *   get:
 *     summary: List active products, optionally filtered by category
 *     description: Retrieves a list of all products marked as active, optionally filtered by a category ID. Products are ordered by name.
 *     tags:
 *       - Products
 *     parameters:
 *       - in: query
 *         name: category_id
 *         schema:
 *           type: integer
 *         required: false
 *         description: The ID of the category to filter products by.
 *     responses:
 *       200:
 *         description: A list of active products.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 data:
 *                   type: array
 *                   items:
 *                     type: object
 *                     properties:
 *                       id: { type: integer }
 *                       category_id: { type: integer }
 *                       name: { type: string }
 *                       description: { type: string, nullable: true }
 *                       price: { type: number }
 *                       image_url: { type: string, nullable: true }
 *                       preparation_time: { type: integer, nullable: true }
 *                       highlight: { type: boolean }
 *                       active: { type: boolean }
 *       400:
 *         description: Invalid category_id parameter.
 *       500:
 *         description: Internal server error or database error.
 */
export async function GET(request: Request) {
  try {
    // Get D1 database binding
    const { env } = getRequestContext();
    const db = env.DB;

    // Get category_id from query parameters
    const { searchParams } = new URL(request.url);
    const categoryIdParam = searchParams.get("category_id");
    let categoryId: number | null = null;

    if (categoryIdParam) {
      categoryId = parseInt(categoryIdParam, 10);
      if (isNaN(categoryId)) {
        return NextResponse.json(
          { error: "Invalid category_id parameter. Must be an integer." },
          { status: 400 }
        );
      }
    }

    let query = "SELECT id, category_id, name, description, price, image_url, preparation_time, highlight, active FROM products WHERE active = TRUE";
    const queryParams: (number | string)[] = [];

    if (categoryId !== null) {
      query += " AND category_id = ?";
      queryParams.push(categoryId);
    }

    query += " ORDER BY name ASC";

    // Prepare and execute the database query
    const stmt = db.prepare(query).bind(...queryParams);
    const { results } = await stmt.all<Product>();

    return NextResponse.json({ data: results });
  } catch (error) {
    console.error("Error fetching products:", error);
    const errorMessage = error instanceof Error ? error.message : "An unexpected error occurred";
    return NextResponse.json(
      { error: "Failed to fetch products", details: errorMessage },
      { status: 500 }
    );
  }
}

