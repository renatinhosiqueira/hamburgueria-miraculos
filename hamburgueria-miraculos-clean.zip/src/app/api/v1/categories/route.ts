import { getRequestContext } from "@cloudflare/next-on-pages";
import { NextResponse } from "next/server";

// Define the expected structure for a Category
interface Category {
  id: number;
  name: string;
  description: string | null;
  image_url: string | null;
  display_order: number;
  active: boolean;
  created_at: string;
  updated_at: string;
}

export const runtime = "edge"; // Specify edge runtime

/**
 * @swagger
 * /api/v1/categories:
 *   get:
 *     summary: List all active categories
 *     description: Retrieves a list of all categories marked as active, ordered by display_order.
 *     tags:
 *       - Categories
 *     responses:
 *       200:
 *         description: A list of active categories.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 data:
 *                   type: array
 *                   items:
 *                     type: object
 *                     properties:
 *                       id: { type: integer }
 *                       name: { type: string }
 *                       description: { type: string, nullable: true }
 *                       image_url: { type: string, nullable: true }
 *                       display_order: { type: integer }
 *                       active: { type: boolean }
 *       500:
 *         description: Internal server error or database error.
 */
export async function GET(request: Request) {
  try {
    // Get D1 database binding
    const { env } = getRequestContext();
    const db = env.DB;

    // Query the database for active categories, ordered by display_order
    const stmt = db.prepare(
      "SELECT id, name, description, image_url, display_order, active FROM categories WHERE active = TRUE ORDER BY display_order ASC"
    );
    const { results } = await stmt.all<Category>();

    return NextResponse.json({ data: results });
  } catch (error) {
    console.error("Error fetching categories:", error);
    // It's good practice to check the error type if possible
    const errorMessage = error instanceof Error ? error.message : "An unexpected error occurred";
    return NextResponse.json(
      { error: "Failed to fetch categories", details: errorMessage },
      { status: 500 }
    );
  }
}

