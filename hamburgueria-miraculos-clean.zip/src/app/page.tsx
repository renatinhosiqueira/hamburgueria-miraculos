"use client"; // Mark this component as a Client Component

import { useState, useEffect } from 'react';

// Define interfaces for data structures
interface Category {
  id: number;
  name: string;
}

interface Product {
  id: number;
  category_id: number;
  name: string;
  description: string | null;
  price: number;
  image_url: string | null;
}

// Category List Component
function CategoryList({ categories, selectedCategoryId, onSelectCategory }: {
  categories: Category[];
  selectedCategoryId: number | null;
  onSelectCategory: (id: number | null) => void;
}) {
  return (
    <nav className="bg-gray-100 p-4 mb-6 rounded-lg shadow">
      <ul className="flex space-x-4 overflow-x-auto">
        <li>
          <button
            onClick={() => onSelectCategory(null)} // Button for "All"
            className={`px-4 py-2 rounded-md font-semibold transition-colors duration-200 ${selectedCategoryId === null ? 'bg-red-500 text-white' : 'bg-white text-gray-700 hover:bg-gray-200'}`}
          >
            Todos
          </button>
        </li>
        {categories.map((category) => (
          <li key={category.id}>
            <button
              onClick={() => onSelectCategory(category.id)}
              className={`px-4 py-2 rounded-md font-semibold transition-colors duration-200 whitespace-nowrap ${selectedCategoryId === category.id ? 'bg-red-500 text-white' : 'bg-white text-gray-700 hover:bg-gray-200'}`}
            >
              {category.name}
            </button>
          </li>
        ))}
      </ul>
    </nav>
  );
}

// Product Card Component
function ProductCard({ product }: { product: Product }) {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden transform transition-transform duration-300 hover:scale-105">
      <div className="h-48 bg-gray-200 flex items-center justify-center">
        {product.image_url ? (
          <img src={product.image_url} alt={product.name} className="h-full w-full object-cover" />
        ) : (
          <span className="text-gray-500">Sem Imagem</span>
        )}
      </div>
      <div className="p-4">
        <h3 className="text-lg font-semibold mb-1 text-gray-800">{product.name}</h3>
        {product.description && (
          <p className="text-sm text-gray-600 mb-2 h-10 overflow-hidden">{product.description}</p>
        )}
        <div className="flex justify-between items-center mt-4">
          <span className="text-xl font-bold text-red-600">R$ {product.price.toFixed(2)}</span>
          <button className="bg-yellow-400 text-gray-900 font-semibold px-4 py-2 rounded-md hover:bg-yellow-500 transition-colors duration-200">
            Adicionar
          </button>
        </div>
      </div>
    </div>
  );
}

// Main Page Component
export default function HomePage() {
  const [categories, setCategories] = useState<Category[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [selectedCategoryId, setSelectedCategoryId] = useState<number | null>(null);
  const [isLoadingCategories, setIsLoadingCategories] = useState(true);
  const [isLoadingProducts, setIsLoadingProducts] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Fetch categories on component mount
  useEffect(() => {
    async function fetchCategories() {
      setIsLoadingCategories(true);
      setError(null);
      try {
        const response = await fetch('/api/v1/categories');
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        setCategories(data.data || []);
      } catch (e) {
        console.error("Failed to fetch categories:", e);
        setError("Falha ao carregar categorias.");
      } finally {
        setIsLoadingCategories(false);
      }
    }
    fetchCategories();
  }, []);

  // Fetch products when selected category changes
  useEffect(() => {
    async function fetchProducts() {
      setIsLoadingProducts(true);
      setError(null);
      let url = '/api/v1/products';
      if (selectedCategoryId !== null) {
        url += `?category_id=${selectedCategoryId}`;
      }

      try {
        const response = await fetch(url);
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        setProducts(data.data || []);
      } catch (e) {
        console.error("Failed to fetch products:", e);
        setError("Falha ao carregar produtos.");
        setProducts([]); // Clear products on error
      } finally {
        setIsLoadingProducts(false);
      }
    }
    fetchProducts();
  }, [selectedCategoryId]); // Re-run effect when selectedCategoryId changes

  const handleSelectCategory = (id: number | null) => {
    setSelectedCategoryId(id);
  };

  return (
    <main className="container mx-auto p-4 md:p-8">
      <header className="text-center mb-8">
        <h1 className="text-4xl font-bold text-red-600">Hamburgueria Miraculos</h1>
        <p className="text-lg text-gray-600 mt-2">Faça seu pedido!</p>
      </header>

      {isLoadingCategories ? (
        <div className="text-center text-gray-500">Carregando categorias...</div>
      ) : (
        <CategoryList
          categories={categories}
          selectedCategoryId={selectedCategoryId}
          onSelectCategory={handleSelectCategory}
        />
      )}

      {error && (
        <div className="text-center text-red-500 bg-red-100 p-4 rounded-md mb-6">
          Erro: {error}
        </div>
      )}

      {isLoadingProducts ? (
        <div className="text-center text-gray-500 mt-8">Carregando produtos...</div>
      ) : (
        <section className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {products.length > 0 ? (
            products.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))
          ) : (
            <div className="col-span-full text-center text-gray-500 mt-8">
              Nenhum produto encontrado nesta categoria.
            </div>
          )}
        </section>
      )}

      {/* Placeholder for Cart/Order Summary */}
      {/* <div className="fixed bottom-4 right-4 bg-blue-500 text-white p-4 rounded-full shadow-lg">
        🛒 Carrinho (0)
      </div> */}
    </main>
  );
}

