import { Providers } from './providers';
import Navigation from '@/components/Navigation';

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="pt-BR">
      <head>
        <title>Hamburgueria Miraculos - Autoatendimento</title>
        <meta name="description" content="Sistema de autoatendimento da Hamburgueria Miraculos" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="/favicon.ico" />
      </head>
      <body>
        <Providers>
          <div className="min-h-screen bg-gray-50">
            <Navigation />
            <main className="pt-20">
              {children}
            </main>
            <footer className="bg-gray-800 text-white py-6 mt-12">
              <div className="container mx-auto px-4">
                <div className="flex flex-col md:flex-row justify-between">
                  <div className="mb-4 md:mb-0">
                    <h3 className="text-xl font-bold mb-2">Hamburgueria Miraculos</h3>
                    <p className="text-gray-400">Bairro Cascatinha, Poços de Caldas</p>
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold mb-2">Horário de Funcionamento</h4>
                    <p className="text-gray-400">Segunda a Domingo: 18h às 23h</p>
                  </div>
                </div>
                <div className="border-t border-gray-700 mt-6 pt-6 text-center text-gray-400">
                  <p>&copy; {new Date().getFullYear()} Hamburgueria Miraculos. Todos os direitos reservados.</p>
                </div>
              </div>
            </footer>
          </div>
        </Providers>
      </body>
    </html>
  );
}
